import Link from 'next/link';
import React, { useState } from 'react'

export default function events() {


  const [newItem,setNewItem] = useState("");
  const [items,setItems] = useState([]);


  function addItem(){

    if(!newItem){
      alert("Enter an event");
      return;
    }

    const item = {
      id:Math.floor(Math.random()*1000),
      value: newItem
    };

    setItems(oldList => [...oldList,item]);
    setNewItem("");
    console.log(items);
  }

  return (
    <div className='bg-slate-500 h-screen flex flex-col justify-center items-center'>
      <div className='border border-black rounded-lg text-black w-96 h-96 flex flex-col items-center pt-20'>  
        <h1 className='text-3xl font-bold underline'>Events</h1><br/>
        <input className='border border-black' type='text' placeholder='Add the events' value={newItem} onChange={e => setNewItem(e.target.value)}/>
        <Link href='/detailevent'>
        <button className='border border-black rounded-lg w-16 bg-black text-white hover:bg-white hover:text-black' onClick={()=> addItem()}>Add</button>
        {/* <ul>
          {items.map(item => {
            return(
              <li className='space-x-3' key={item.id}>Event name:{item.value}</li>
            )
          })}
        </ul> */}
        </Link>
        </div>
    </div>
  )
}
