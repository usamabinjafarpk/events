import React from 'react'

export default function detailevent() {
    
  return (
    <div className='bg-slate-500 w-screen h-screen flex justify-center pt-20'>
        <div className='flex flex-col'>
        <h1 className='font-bold text-4xl underline'>Event Details</h1><br/>
            <p>Event name:</p>
            <p>Event description</p>
        </div>
        
    </div>
  )
}
